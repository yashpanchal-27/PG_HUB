require("dotenv").config();
const router = require("express").Router();
const passport = require("passport");

const { generateToken } = require("../utils/generateToken");
const { verifyToken } = require("../middlewares/verifyToken");
const authController = require("../controllers/authController");

router.post("/signup", authController.userRegistration);
router.post("/signin", authController.userLogin);
router.get("/verify-email", authController.VerifyEmail);
router.get("/getUserData", verifyToken, authController.userGetUserData);
router.put("/updateUserData/:userId", authController.updateUserData);

// google auth
router.get("/google", authController.google);
router.get("/google/callback", authController.gCallbacks, async (req, res) => {
  try {
    const token = await generateToken({
      username: req.user.userName,
      email: req.user.email,
      picture: req.user.picture,
    });
    res.redirect(`${process.env.CLIENT_URL}?token=${token}`);
  } catch (err) {
    console.log(err);
  }
});

// facebook auth
router.get("/facebook", authController.facebook);
router.get(
  "/facebook/callback",
  authController.fbCallbacks,
  async (req, res) => {
    try {
      const token = await generateToken({
        username: req.user.userName,
        email: req.user.email,
        picture: req.user.picture,
      });
      res.redirect(`${process.env.CLIENT_URL}?token=${token}`);
    } catch (err) {
      console.log(err);
    }
  }
);

module.exports = router;
