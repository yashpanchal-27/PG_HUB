require("dotenv").config();
const router = require("express").Router();

const renterController = require("../controllers/renterController");

router.get("/registeredPgs/:renterId", renterController.getRegisteredPgs);

module.exports = router;
