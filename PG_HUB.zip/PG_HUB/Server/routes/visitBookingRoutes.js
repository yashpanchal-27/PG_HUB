const routes = require('express').Router();
const visitBookingController = require("../controllers/visitBookingController")

routes.post("/newVisit", visitBookingController.createVisitRequest);

routes.get("/ownerVisit/:ownerId", visitBookingController.ownerVisit);
routes.get("/renterVisit/:renterId", visitBookingController.renterVisit);

module.exports = routes;