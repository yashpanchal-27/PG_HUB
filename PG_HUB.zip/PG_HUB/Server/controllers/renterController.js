const mongoose = require("mongoose");

const { PgInfoModel } = require("../models/PgInfoModel");
const { BookingModel } = require("../models/BookingModel");
const UserDataModel = require("../models/UserDataModel");

exports.getRegisteredPgs = async (req, res) => {
  try {
    const renterId = req.params.renterId;

    const registered = await BookingModel.find({renterId:renterId,paymentStatus:"SUCCESS"}).populate({
        path: "pgId",
        // select: "_id pgName city isFull pgAddress images",
      });

    console.log(registered);
    
    return res
      .status(500)
      .json({ success: true, message: "Succesfully Fetched Registerd data" ,registered:registered});
  } 
  catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Error in Fetching PG's Details" });
  }
};
