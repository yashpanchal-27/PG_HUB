const { VisitBookingModel } = require("../models/VisitBookingModel");

// Create a new visit request
exports.createVisitRequest = async (req, res) => {
  try {
    const { visitData } = req.body;
    const visitRequest = new VisitBookingModel(visitData);
    
    await visitRequest.validate();
    
    const savedRequest = await visitRequest.save();
    if (savedRequest) {
      return res
        .status(201)
        .json({ success: true, message: "Visit book succesfully" });
    } else {
      return res
        .status(500)
        .json({ success: false, message: "Error in saving Visitrequest data" });
    }
  } catch (error) {
    if (error.name === "ValidationError") {
      return res
        .status(400)
        .json({ message: `Validation Error: ${error.message}` });
    } else {
      return res.status(500).json({ message: error.message });
    }
  }
};

exports.ownerVisit = async (req, res) => {
  try {
    const { ownerId } = req.params;
    // console.log(ownerId);

    // let visitRequests;

    const visitRequests = await VisitBookingModel.find({ ownerId: ownerId })
      .populate({
        path: "pgId",
        select: "_id pgName city isFull pgAddress",
      })
      .populate({
        path: "renterId",
        select: "_id userName email mobileNo",
      });

    // Sorting visitRequests based on visitDate and visitTime
    visitRequests.sort((a, b) => {
      // First, compare by visitDate
      const dateComparison = new Date(a.visitDate) - new Date(b.visitDate);

      // If visitDates are the same, compare by visitTime
      if (dateComparison === 0) {
        const timeA = new Date(`1970-01-01T${a.visitTime}:00Z`).getTime();
        const timeB = new Date(`1970-01-01T${b.visitTime}:00Z`).getTime();
        return timeA - timeB;
      }

      return dateComparison;
    });

    if (!visitRequests.length) {
      return res.status(404).json({
        success: false,
        message: "No visit requests found for this owner.",
      });
    }

    return res.status(200).json({
      success: false,
      message: "Succesfully fetch visit request Data",
      visitRequestsData: visitRequests,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.renterVisit = async (req, res) => {
  try {
    const { renterId } = req.params;
    // console.log(renterId);

    // let visitRequests;

    const visitRequests = await VisitBookingModel.find({ renterId: renterId })
      .populate({
        path: "pgId",
        select: "_id pgName city isFull pgAddress",
      })
      .populate({
        path: "ownerId",
        select: "_id userName email mobileNo",
      });

    // Sorting visitRequests based on visitDate and visitTime
    visitRequests.sort((a, b) => {
      // First, compare by visitDate
      const dateComparison = new Date(a.visitDate) - new Date(b.visitDate);

      // If visitDates are the same, compare by visitTime
      if (dateComparison === 0) {
        const timeA = new Date(`1970-01-01T${a.visitTime}:00Z`).getTime();
        const timeB = new Date(`1970-01-01T${b.visitTime}:00Z`).getTime();
        return timeA - timeB;
      }

      return dateComparison;
    });

    if (!visitRequests.length) {
      return res.status(404).json({
        success: false,
        message: "No visit requests found for this owner.",
      });
    }

    return res.status(200).json({
      success: false,
      message: "Succesfully fetch visit request Data",
      visitRequestsData: visitRequests,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};