export const mockAccordionData = [
    {
      question: "How do I create a new user?",
      details:
        "To create a new user, navigate to the Users section in the admin dashboard. Click on the 'Add User' button and fill in the required information such as username, email, and password. Then, click on the 'Save' button to create the user.",
    },
    {
      question: "How can I manage permissions for users?",
      details:
        "To manage permissions for users, go to the Permissions section in the admin dashboard. Here, you can assign or revoke specific permissions for each user by selecting the user and adjusting their permissions accordingly.",
    },
    {
      question: "What is the process for adding a new product?",
      details:
        "To add a new product, navigate to the Products section in the admin dashboard. Click on the 'Add Product' button and fill in the details such as product name, description, price, and images. Finally, click on the 'Save' button to add the product.",
    },
    {
      question: "How do I update existing user information?",
      details:
        "To update existing user information, find the user in the Users section of the admin dashboard. Click on the user to view their details, then click on the 'Edit' button. Update the necessary information and click on the 'Save' button to apply the changes.",
    },
    {
      question: "What are the steps to delete a product?",
      details:
        "To delete a product, navigate to the Products section in the admin dashboard. Find the product you want to delete and click on the 'Delete' button. Confirm the action when prompted, and the product will be permanently removed from the system.",
    },
    {
      question: "How can I view sales reports?",
      details:
        "To view sales reports, go to the Reports section in the admin dashboard. Here, you can generate various reports such as sales by day, month, or year, top-selling products, and revenue trends.",
    },
    {
      question: "What options are available for managing customer orders?",
      details:
        "To manage customer orders, navigate to the Orders section in the admin dashboard. Here, you can view all orders, process pending orders, update order status, and manage order fulfillment and shipping details.",
    },
    {
      question: "How do I customize the appearance of the dashboard?",
      details:
        "To customize the appearance of the dashboard, go to the Settings section in the admin dashboard. Here, you can adjust various settings such as theme colors, layout options, and dashboard widgets.",
    },
    {
      question: "What security measures are in place to protect user data?",
      details:
        "We take security seriously and have implemented various measures to protect user data. These include encryption of sensitive information, regular security audits, and compliance with industry standards and regulations.",
    },
    {
      question: "How can I contact support for assistance?",
      details:
        "For assistance or support inquiries, please contact our customer support team via email at support@example.com or by phone at 1-800-123-4567. Our support team is available to assist you with any questions or issues you may have.",
    },
  ];